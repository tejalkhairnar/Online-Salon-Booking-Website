<!--footer-->
    <div class="footer">
       <p>&copy; 2022 Anjali and Tejal : Admin Page.</p>
    </div>
        <!--//footer-->